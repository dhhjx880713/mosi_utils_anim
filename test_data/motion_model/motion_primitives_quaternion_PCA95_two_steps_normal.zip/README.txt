Data format for motion primitive files:

The file contains necessary data to reconstruct morphable model (parameters of GMM) and eigenvectors for spatial and temporal parameters in order to reconstruct motion data.

Name convension: <elementary_action>_<motion primitive>_<feature>_mm.json

The data is stored as Python dictionary. The keys and corresponding values are as follows:
'mpa_name': string, name of motion primitive, <elementary motion>_<primitive name>
'gmm_weights': list, weight vector for Gaussians
'gmm_means': list, a list of mean vector for each multi-variable Gaussian
'gmm_covars': list, a list of covariance matrix for each mulit-variable Gaussian
'eigen_vectors_spatial': list, a list of eigenvectors for spatial parameters
'mean_spatial_vector': list, a list of mean motion parameters for spatial parameter
'n_canonical_frames': int, number of frames in canonical timeline
'translation_maxima': float_value vector, scaling vector for root position
'n_basis_spatial': int, number of Bspline basis functions for representing spatial motion data as functioal data
'eigen_vectors_time': list, a list of eigenvectors for temporal parameter
'mean_time_vector': list, a list of mean motion parameters for temporal parameter
'n_dim_spatial': int, number of dimensions for spatial parameter
'n_basis_time': int, number of Bspline basis functions for representing temporal motion data as functional data 

